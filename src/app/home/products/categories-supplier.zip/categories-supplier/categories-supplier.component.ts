import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-categories-supplier',
  templateUrl: './categories-supplier.component.html',
  styleUrls: ['./categories-supplier.component.scss']
})
export class CategoriesSupplierComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
